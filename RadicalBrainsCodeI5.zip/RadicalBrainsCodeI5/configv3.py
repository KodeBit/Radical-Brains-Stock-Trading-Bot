# Radical Brains - ALPACA API CONFIGURATION
# To get started with Alpaca's trading API, make sure you’ve created an account at https://alpaca.markets/ 
# and have your API keys ready (API_KEY and SECRET_KEY). Let’s dive into it!

# I've already set up my keys below for paper trading.
API_KEY = 'PK07YU79XD88KJE3OOPN'
SECRET_KEY = 'Qz5DpbsI4CHEeh4e2shov8QTwjaSONrT7ZMJNoze'

# Using Alpaca's paper trading API here. If you're going live, switch to 'https://api.alpaca.markets'
ALPACA_URL = 'https://paper-api.alpaca.markets'

# API request headers for secure communication with Alpaca
HEADERS = {
    'APCA-API-KEY-ID': API_KEY,
    'APCA-API-SECRET-KEY': SECRET_KEY
}

# Quick heads-up:
# - The API_KEY and SECRET_KEY are your unique credentials, tied to your Alpaca account.
# - Keep these keys safe and never share them publicly (yes, seriously, protect them!).
# - We’re working in the paper trading environment for testing, but you can always switch to the live API for real trades.
